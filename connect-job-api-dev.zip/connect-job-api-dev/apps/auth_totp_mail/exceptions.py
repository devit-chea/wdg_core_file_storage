class ExpiredError(Exception):
    pass
