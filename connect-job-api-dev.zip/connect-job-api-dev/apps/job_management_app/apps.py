from django.apps import AppConfig


class JobManagementAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.job_management_app"
